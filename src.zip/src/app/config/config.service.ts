import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from '../services';

@Injectable()
export class ConfigService {
   
  httpOptions: {}  
  authToken: string

  constructor(private http: HttpClient, private authService: AuthenticationService) { }

  ngInit() {
    this.authToken = this.authService.currentUser[0].token
  }

  getHeader(): {}{
    return this.httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': '1'
        })
      };
  }
}

