import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsageTipsComponent } from './usage-tips.component';

describe('UsageTipsComponent', () => {
  let component: UsageTipsComponent;
  let fixture: ComponentFixture<UsageTipsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsageTipsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsageTipsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
