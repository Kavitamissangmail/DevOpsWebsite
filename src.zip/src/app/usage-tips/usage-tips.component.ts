import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usage-tips',
  templateUrl: './usage-tips.component.html',
  styleUrls: ['./usage-tips.component.css']
})
export class UsageTipsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
