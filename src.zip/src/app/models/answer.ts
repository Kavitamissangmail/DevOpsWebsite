export class Answer {
    constructor(
        public qId: number,
        public ratingId: number,
        public comment?: string,
        public answerId?: number,
      ) {  }
}
