import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountInfoComponent } from './account-info/account-info.component';
import { HomeComponent } from './home/home.component';
import { ApproachComponent } from './approach/approach.component';
import { MeasureComponent } from './measure/measure.component';
import { LoginComponent } from './login/login.component';
import { Authentication } from './services/Authentication';
import { ReportComponent } from './report/report.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent},
  { path:'home', component: HomeComponent },
  { path:'approach', component: ApproachComponent},
  { path:'reports', component: ReportComponent},
  { path:'account-info', component: AccountInfoComponent , canActivate: [Authentication]},
  { 
    path: 'measure', 
    component: MeasureComponent,
    canActivate: [Authentication]
    // children: [
    //   {
    //     path: '',
    //     component: CultureComponent
    //   },
    //   { 
    //     path: 'automate',
    //     component: AutomateComponent
    //   }
    // ]
   },
  // { path: 'measure/:id', component: MeasureComponent},
   //{ path:'', component: HomeComponent},

  //  { path: '', component: HomeComponent }, // pathMatch: 'full' is optional if defined in this order
    { path: '',   redirectTo: '/login', pathMatch: 'full' },
    // otherwise redirect to login
    { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
