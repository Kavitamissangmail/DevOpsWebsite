import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { Measure } from './measure';
import { MeasureList } from './mock-measure';
import { catchError, map, tap } from 'rxjs/operators';
import { MessageService, AuthenticationService } from '../services';
import { ConfigService } from '../config/config.service';
import { environment } from '../../environments/environment'
import { Answer } from '../models';

@Injectable({
  providedIn: 'root'
})
export class MeasureService {
  currentUser: any

  constructor(
    private http: HttpClient,
    private messageService: MessageService,
    private configService: ConfigService,
    private authService: AuthenticationService
    ) { 
      this.authService.currentUser.subscribe(user=> this.currentUser = user)
  } 

  private httpOptions = {
    headers: new HttpHeaders({
      //'Access-Control-Request-Method': 'GET',
      //'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
      'Content-Type':  'application/json',
      'Access-Control-Allow-Origin': '*',
      //'token': user.token,
     // 'Access-Control-Allow-Credentials': 'true'
    })
  };



  /** GET questions from the stub file */
  // getTabQuestions(): Observable<Measure[]> {
  //  return of(MeasureList)
  // }

  getTabs (): Observable<any[]> {
    return this.http.get<any>(`${environment.apiUrl}devops/getAllCategories`, this.httpOptions)
    .pipe(
      catchError(<any>[])
    )
  } 

  /** GET questions from the server */
  getTabQuestions (tabId): Observable<Measure[]> {
    //return this.http.get<any>(`${environment.apiUrl}devops/getAllQuestions`, this.httpOptions)
    return this.http.get<any>(`${environment.apiUrl}devops/getQuestions/${tabId}`, this.httpOptions)
    .pipe(
      catchError(<any>[])
    )
  }

  getAllAnswers(): Observable<Answer[]> {
    return this.http.get<any>(`${environment.apiUrl}devops/getAnswers/user/${this.currentUser.userId}`, this.httpOptions)
    .pipe(map((answers)=>{
      return answers
    })
    ,catchError(<any>[]))
  }

  // getAnswer(id: number | string) {
  //   return this.getAllAnswers().pipe(
  //     map((answers: any[]) => answers.find(answer => answer.answerId === +id))
  //   );
  // }

  createQuestionAnswer(answerModel) {
    return this.http.post<Answer>(`${environment.apiUrl}devops/user/${this.currentUser.userId}/answer`, JSON.stringify(answerModel), this.httpOptions)
    .pipe(map((response)=>{
      // {"answerId":4000,"qId":2200,"ratingId":1,"comment":"Comment 1"}
      return response
    }))
  }


  updateQuestionAnswer(answerModel) {
    return this.http.put<Answer>(`${environment.apiUrl}devops/answer`, answerModel)
    .pipe(map((response)=>{
      // {"answerId":4000,"qId":2200,"ratingId":1,"comment":"Comment 1"}
      return response
    }))

  }
}
