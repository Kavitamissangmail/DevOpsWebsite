
import { Component } from '@angular/core'

@Component({
    selector: 'account-info',
    templateUrl: './automate.component.html',
   // styleUrls: ['./culture.component.css']

})
export class AutomateComponent {
}