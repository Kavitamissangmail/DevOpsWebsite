
import { Component, QueryList } from '@angular/core'
import {SelectItem} from 'primeng/api';
import { MeasureService } from '../measure.service';
import { ActivatedRoute } from '@angular/router';
import { Measure, Question } from '../measure';
interface rating {
    name: string;
    code: string;
  }

@Component({
    selector: 'questions',
    templateUrl: './culture.component.html',
   // styleUrls: ['./culture.component.css']

})
export class CultureComponent {

    ratings: SelectItem[];
    selectedRating: rating
    questions: Question[]
    index: number = 0;

    constructor(private mService: MeasureService, private route: ActivatedRoute) {
        this.ratings = [
            {label:'Select Rating', value:null},
            {label:'1', value:1},
            {label:'2', value:2},
            {label:'3', value:3},
            {label:'4', value:4},
            {label:'5', value:5}
        ];
        this.index = this.route.snapshot.params.id?this.route.snapshot.params.id-1:0
        this.getQues()
    }

    detectChanges(){
        this.getQues()
    }

    // getQues(): void {
    //     this.mService.getQuestions().subscribe( questionObj => console.log(questionObj[this.route.snapshot.params.id-1]))
    // }

    getQues(): void {
      //  this.mService.getQuestions().subscribe( questionObj => this.questions = questionObj[this.index].questions)
    }
}