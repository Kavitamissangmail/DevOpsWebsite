import { Component, OnInit, ViewChild  } from '@angular/core'
import { Measure, Question } from './measure';
import { MeasureService } from './measure.service';
import { Router, ActivatedRoute } from "@angular/router";
import {ConfirmationService} from 'primeng/api';
import {SelectItem} from 'primeng/api';
import { Answer } from '../models/answer';
import { Observable, pipe } from 'rxjs';
import { map } from 'rxjs/operators';
import { AlertService } from '../services';
import { UploaderService } from './upload.service';


interface tabView {
label: string,
isDisabled: boolean,
contentType: string
}


@Component({
selector: 'account-info',
templateUrl: './measure.component.html',
styleUrls: ['./measure.component.css']

})
export class MeasureComponent implements OnInit {

    items: tabView[];
    tabs: any[]
    tabIndex: number = 0;
    qList: any[]
    currentQuestionIndex: number = 0
    totalRecord: number = 0
    currentQuestion: object
    display: boolean = false;
    ratings: SelectItem[];
    qFile = new Array()
    model: Answer
    @ViewChild('myform') form: any;
    answerStatus = new Array()
    activeTabName: string
    allAnswers: Answer[]
    message: string;
    fileId:number;
    qId:number
    showDialog() {
        this.display = true;
    }

    constructor(
        private mService: MeasureService, 
        private router: Router,
        private activeRoute: ActivatedRoute,
        private alertService: AlertService,
        private confirmationService: ConfirmationService,
        private uploaderService: UploaderService){
    }


    ngOnInit() {
        this.ratings = [
            {label:'Select Rating', value:''},
            {label:'1', value:1},
            {label:'2', value:2},
            {label:'3', value:3},
            {label:'4', value:4},
            {label:'5', value:5}
        ];
        this.getTabs()
        this.mService.getAllAnswers().subscribe((data => {
            this.allAnswers = data
        }), error => console.log('error', error));
    }



    confirmSwitchTab(type) {
        this.confirmationService.confirm({
            header: "Measure Assessment",
            message: type==='Next'? '<center><h6><b>'+this.activeTabName+'</b> assessment is over.</h6>Taking you to next section</center>':'Would like to go back to previous section?',
            rejectVisible:false,
            acceptVisible:true,
            acceptLabel: "Ok",
            accept: () => {
                if(type === 'Next') {
                    this.saveQuestion()
                    this.currentQuestionIndex = 0
                    this.tabIndex =  this.tabIndex === this.tabs.length?1:this.tabIndex+1
                    this.answerStatus.push(this.tabIndex)
                    this.getAllQues()
                    this.getQuestion(this.currentQuestionIndex)
                    //this.form.reset();
                } else if(type === 'Prev') {
                    this.tabIndex =  this.tabIndex === 0?0:this.tabIndex-1
                    this.getAllQues()
                    this.currentQuestionIndex = this.qList.length-1
                }
            },
            reject: () => {
            }
        });
    }

    BrowseFiles() {
        this.qId=this.model.qId;
        this.showDialog()
        this.getFiles()
    }


    openNext() {
        if(this.currentQuestionIndex === this.qList.length-1){
            //console.log('this.answerStatus', this.answerStatus)
            if(this.tabIndex === this.tabs.length-1 && this.currentQuestionIndex === this.qList.length-1){
               // alert('Thank you for your time!')
                this.confirmationService.confirm({
                    header: "",
                    message: '<center><h6><b>Submission Sucessful</b></h6>Thank you for the assessment</center>',
                    rejectVisible:false,
                    acceptVisible:true,
                    acceptLabel: "Ok",
                    accept: () => {
                        this.router.navigate(['home'])
                    },
                    reject: () => {
                        this.router.navigate(['home'])
                    }
                });
            } else {
                this.confirmSwitchTab("Next")
            }

            // this.currentQuestionIndex = 0
            // this.tabIndex =  this.tabIndex === this.questions.length?1:this.tabIndex+1
            // this.answerStatus.push(this.tabIndex)
            // this.getAllQues()
            // this.form.reset();
        } else if(this.currentQuestionIndex < this.qList.length-1){
            // Validate & Post the rating question
            this.saveQuestion()
            this.currentQuestionIndex = (this.currentQuestionIndex === this.qList.length) ? this.qList.length-1 : this.currentQuestionIndex + 1;
            this.getQuestion(this.currentQuestionIndex)
           // this.form.reset();
        }
    }

    openPrev() {
        if(this.currentQuestionIndex===0){
           // this.confirmSwitchTab("Prev")
           this.tabIndex =  this.tabIndex === 0?0:this.tabIndex-1
           //this.currentQuestionIndex = 0
           console.log('this.qList', this.qList)
           this.getAllQues()
           this.currentQuestionIndex = this.qList.length-1  // not in use if fetch questions by category  
           this.getQuestion(this.currentQuestionIndex)         
        } else {
            this.currentQuestionIndex = (this.currentQuestionIndex === 0) ? 0 : this.currentQuestionIndex - 1;
            this.getQuestion(this.currentQuestionIndex)
        }
    }
    
    handleChange(e) {
        // this.tabIndex = e.index
        // this.currentQuestionIndex = 0
        // this.getAllQues()
    }

    getCurrentTab() : any {
        // console.log(this.tabs)
         return this.tabs.find((value,key)=> {
             return key === this.tabIndex
         })
     }


    getTabs(): void {
        this.mService.getTabs().subscribe((tabCategoy)=> {
            this.tabs = tabCategoy
            this.getAllQues()
            this.getQuestion(this.currentQuestionIndex)
        })
    }

    getAllQues(): void {
        const tabId = this.getCurrentTab()
        console.log('tabId', tabId)
        /*  Use when call all question with category in single call */
        console.log("currentQuestionIndex",this.currentQuestionIndex)
        const getTabQuestions = this.tabs.find(tab => tab.cId === tabId.cId)
        this.qList = getTabQuestions.questions.length>0?getTabQuestions.questions:[]
        this.activeTabName =  this.tabs.length>0 && this.getCurrentTab().categoryName
        this.totalRecord = this.qList.length

        /*  End of Use when call question by tab Id */


        /*  Use when call question by tab Id

        this.mService.getTabQuestions(tabId.cId).subscribe( questionObj => {
            this.qList = questionObj.length>0?questionObj:[]
            this.activeTabName =  this.tabs.length>0 && this.getCurrentTab().categoryName
            this.getQuestion(this.currentQuestionIndex)
            this.totalRecord = this.qList.length
        })

        */

    }

    change(){
        //console.log('Model onChange', this.model)
    }

    getQuestion(index) {
        //console.log(this.qList)
        this.currentQuestion = this.qList.filter(((value, key) => {
            if(key == index){
               const aRecord =  this.allAnswers.length>0 && this.allAnswers.find(answer => answer.qId===value.qId)
               this.model = !aRecord?new Answer(value.qId, null, null):aRecord
               return value
            }
        }))
        
    }

    submitted = false;
    saveQuestion(){
        this.submitted = true;
        console.log(this.model)
        const isAnswerFound = this.allAnswers.some( value=> value.qId === this.model.qId )
        if(!isAnswerFound){
            // create new record!
            this.mService.createQuestionAnswer(this.model).subscribe( data => {
                console.log('create', data)
                this.allAnswers.push(data)
            },
            error => {                                                                                                                  
                console.log('create error', error)
            });
        } else {
            // Update the record
            this.mService.updateQuestionAnswer(this.model).subscribe( data => {
                console.log('update', data)
            },
            error => {
                console.log('create error', error)
                this.alertService.error(error);
            });
        }

    }
    getFiles():void{
        console.log("************ into the get files ***********");
        this.uploaderService.getFilesByUserId()
        .subscribe(data=>{
          console.log(data);
          if(!!data){
            this.fileId = data.id;
          this.model=data
          }else{
             console.log("error in getting file data")
          }
          });
        console.log("************ END the get files ***********");
      }
      
    handleFiles(e) {
        console.log("******File Name********* " + e.target.files)
        console.log("value of qid isssssss ",this.qId)
        const file = e.target.files[0]
        // this.qFile = Array.from(e.target.files); 

        // this.qFile.push(e.target.files[0].name)
        if(file){
              this.uploaderService.upload(file,this.qId);

              console.log("value of qfile ", this.qFile);
        }
    }

    clearFile() {
       // this.qFile.splice(1,1);
    }
} 
 
