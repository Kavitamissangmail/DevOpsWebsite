export class Measure {
    id: number;
    categoryName: string;
    questions: Question[];
  } 

export class Rating {
    ratingId: number;
    ratinglabel: string;
    ratingDesc: string;
  }

  export class Question {
    id: number;
    questionlabel: string;
    questionDesc: string;
    ratings?: Rating[]
  } 