import { Measure } from './measure';

export const MeasureList: Measure[] = [
  {
    id: 1,
    categoryName: "Culture",
      questions: [
        { 
          id: 1,
          questionlabel:'Is DevOps Customer or Organisational or Team objective?',
          questionDesc: 'DevOps is a cultural movement, driven by People, Processes and Tools. For DevOps to be successful, it should be the mandate/objective/priority of either Customer, Organisation, team or All i.e. it should be driven consistently and the rigor must come from either customer, organization, teams or all.',
          ratings:[
            {  
              ratingId: 1,
              ratinglabel: 'Objective of None', 
              ratingDesc:'DevOps is neither an objective of Customer nor Organization not Team.' 
            },
            {  
              ratingId: 2,
              ratinglabel: 'Objective of any one', 
              ratingDesc:'DevOps is an objective of either one of Customer or Organization or Team.' 
              },{  
                ratingId: 3,
                ratinglabel: 'Objective of organisation and team', 
                ratingDesc:'DevOps is an objective of Organization and Team only. DevOps does not feature in list of Customer objectives.' 
              },{  
                ratingId: 4,
                ratinglabel: 'Objective of Customer and (organisation or team)', 
                ratingDesc:'DevOps is the objective of Customer and either of Organization or Team.' 
              },
              {  
                ratingId: 5,
                ratinglabel: 'Objective of all three', 
                ratingDesc:'DevOps is the objective of Customer, Organization and Team as well.' 
              }
            ]
        },
        { 
          id: 2,
          questionlabel:'Is there a consensus on strategy on how to implement DevOps?',
          questionDesc: 'DevOps implementation requires different teams - Development, Support, Testing, Infrastructure, Security working together as one team. Since there could different ways to develop and implement DevOps manifesto, it is important that key stakeholders agree on a transformation program. For example, instead of a big bang approach we could start with a couple of pilot projects based on the DevOps approach or implement on the onset of greenfield projects. The pilots could be non-business critical and technology and tool stack where organization benefits most. Clearly this means, a single team integrating all disciplines with clear goals and objectives. All of this would require a clear implementation strategy.',
          ratings:[
            {  
              ratingId: 1,
              ratinglabel: 'No consensus', 
              ratingDesc:'Some may know how to implement DevOps, but, there is no mutual agreement between various teams on how to implement.' 
            },
            {  
              ratingId: 2,
              ratinglabel: '< 25% of consensus exists on the strategy', 
              ratingDesc:'< 25% of stakeholders have a consensus on the strategy to how to implement DevOps' 
              },{  
                ratingId: 3,
                ratinglabel: '25 - 50% of consensus exists on the strategy', 
                ratingDesc:'25-50% of stakeholders have a consensus on the strategy to how to implement DevOps.' 
              },{  
                ratingId: 4,
                ratinglabel: '50 - 75% of consensus exists on the strategy', 
                ratingDesc:'50-75% of stakeholders have a consensus on the strategy to how to implement DevOps.' 
              },
              {  
                ratingId: 5,
                ratinglabel: '100% consensus exists', 
                ratingDesc:'Everyone agrees to the DevOps implementation strategy.' 
              }
            ]
        },
        {
          id: 3,
          questionlabel: 'Does Organizational / Team structure and Tooling support cross-functional teams?',
          questionDesc: 'DevOps manifesto tries to synergize Development and Operations. One strategy proposed by DevOps is to do away with the functional silos altogether and create cross-functional teams (also called multifunctional, poly-skilled, or interdisciplinary). This is especially important from  continuous delivery perspective where teams must have a broader view of delivery. Developing collective responsibility and accountability for the complete lifecycle is more important than it\'s individual components - Implementation, Testing or Operations. Extending this understanding towards supporting tools mandates a tooling which is end-to-end rather than discrete tools supporting individual functional silos. Moreover, creation of cross-functional teams is not forbidden by regulation or "best practice" as Sarbanes-Oxley, ITIL and COBIT nowhere "mandate" segregation of duties.',
          ratings:  [
            {  
              ratingId: 1,
              ratinglabel: 'Both organization and tool do not support', 
              ratingDesc:'The organizational structure does not support dotted-line reporting to support cross-functional teams having separate line managers, elementary toolset changes (e.g. time booking, attendance recording, etc.) from one team to another.' 
            },
            {  
              ratingId: 1,
              ratinglabel: 'Both organization and tool do not support', 
              ratingDesc:'The organizational structure does not support dotted-line reporting to support cross-functional teams having separate line managers, elementary toolset changes (e.g. time booking, attendance recording, etc.) from one team to another.' 
            },
            {  
              ratingId: 1,
              ratinglabel: 'Both organization and tool do not support', 
              ratingDesc:'The organizational structure does not support dotted-line reporting to support cross-functional teams having separate line managers, elementary toolset changes (e.g. time booking, attendance recording, etc.) from one team to another.' 
            },
            {  
              ratingId: 1,
              ratinglabel: 'Both organization and tool do not support', 
              ratingDesc:'The organizational structure does not support dotted-line reporting to support cross-functional teams having separate line managers, elementary toolset changes (e.g. time booking, attendance recording, etc.) from one team to another.' 
            }],
      }
    ]
  },
  {
    id: 2,
    categoryName: "Automate",
    questions: [
        {
            "id": 4,
            "questionlabel": "Does the Tools help people to collaborate?",
            "questionDesc": "Integrated toolset is a must for the successful implementation of Devops. Effective tools may exist for different phases of SDLC and Operations but until and unless these tools are integrated, minimal DevOps benefits would be achieved. Integrated toolset means either same tool is used in multiple SDLC phases or output of one tool is consumed automatically by other tool used in the next SDLC phase. Note that tool integration should not be only unidirectional but bidirectional. How well these tools communicate with each other across different phases of SDLC determines the level of  automation, e.g. the tool used to generate the automatic test cases and data should be able to handle the scenarios resulting from change in development. The updated  test cases and data should be automatically used by the automated testing tool.  This process enables team to continuously integrate their code build to the down stream process. Collaboration tools e.g. Team Foundation, Microsoft Teams, JIRA, HipChat, Pivotal Tracker, ServiceNow, Stack, etc.",
            "ratings": []
        },
        {
            "id": 5,
            "questionlabel": "Do teams continuously work on minimizing manual intervention, improving RFT (right First Time) and reducing CT (Cycle Time)? ",
            "questionDesc": "To gain the maximum benefit out of DevOps implementation, it is vital that the teams work towards reducing / eliminating the noise caused due to various manual interventions existing in a particular system environment. It is recognized that failure of any manual intervention leads to disruption resulting in incidents, major incidents, escalations, customer dissatisfaction, etc. Such issues further take away time of the teams to restore service. Dev and Ops teams must work together in a planned way to identify and minimise all known manual interventions by exploring all possible solutions. It is recommended that a track of all manual interventions is maintained and reasons of not automating is discussed in key review meetings. LEAN methodology can be put in use to identify waste in the system. Eliminating or minimizing waste will help us to reduce the cycle time and also improve right first time.",
            "ratings": []
        }
    ]
  },
  {
    id: 3,
    categoryName: "Measure",
    questions: [
        {
            "id": 6,
            "questionlabel": "Do Teams measure effectiveness of tools and processes used?",
            "questionDesc": "Tools and processes are designed and implemented to assist in the operability of the service. One of the primary objective of the tools and processes is the ease of use & responsiveness of the process. Sometimes tools used by Dev (e.g. project planning tool, etc) could as well be used by Ops teams for their maintenance and planning purposes. Similarly, tools used in production environments, could provide invaluable insight to the system designers and developers on the system performance. While a tool/process may be extremely useful for a particular environment, it may not be that helpful elsewhere. Therefore, effectiveness of tool/process should be measured regularly for any bottlenecks and latency.Critical Success Factors & KPIs can be defined for any process.Request Fulfillment process there may exist CSF e.g. Requests must be fulfilled in an efficient and timely manner that is aligned to agreed service level targets for each type of request, Only authorized requests should be fulfilled, etc. Incident Management process there may exist KPI e.g. Reduction in number of repeated incidents, First time resolution rate, resolution within SLA rate, incident resolution effort, etc. Capacity Management process there may exist KPI e.g. Incidents due to Capacity Shortages, Unplanned Capacity Adjustments, Resolution Time of Capacity Shortage, etc.",
            "ratings": []
        },
        {
            "id": 7,
            "questionlabel": "Are there any measures for evaluating quality of interactions between Dev and Ops?",
            "questionDesc": "DevOps focuses on effective interaction between various teams. There should be regular meeting between the development and operation team throughout the project lifecycle. Similarly, Architects and Systems Designer should be regularly engaged during the support lifecycle. These meetings should not be just limited to checkpoint calls or KT sessions but also focus on service improvement and customer experience.  This may include, user feedback about the application and how to improve that, review of the improvement plan from implementation perspective, Lessons Learnt from various delivery artifacts at various stages of delivery etc. To determine the effectiveness of such interactions, measures such as who all attended the review meetings, Number of ideas progressed, rate of closure of actions from the previous meetings, change in the ownership on unresolved issues, etc should be included.  ",
            "ratings": []
        }
    ]
  },
  {
    id: 4,
    categoryName: "Share",
    questions: [
        {
            "id": 8,
            "questionlabel": "Are there formal Information Sharing session between Dev and Ops?",
            "questionDesc": "Foundation of DevOps success is how well teams and individuals understands each others goals, dificulties & priorities. It is essential that every participant in the development & support teams is able to share information about their area/responsibilities/tasks and communicate, without friction, with each other. It is extremely important that regular feedback sessions are held between different interfaces of software lifecycle without bias. For example, Application performance monitoring stats/RCA for the problem records shared with Development team as part of monthly governance calls. Release & deployment notes shared with support teams in advance for their review and inputs before release etc. Various tools/methodologies that could be used during such sessions are Kanban, Visual Management, Scrum meetings, etc.",
            "ratings": []
        },
        {
            "id": 9,
            "questionlabel": "Do Dev & Ops teams rotate their key personnel between the teams effectively?",
            "questionDesc": "DevOps is all about breaking silos in various teams including but not limited to design, development, Test, environment, deployment, operation and service improvement teams.  Although there should be regular quality interaction between these teams but rotation of key persons between various teams would yield magical results. Infusion of an experienced sustain resource to development team can help the team to foresee support scenarios and would help to devise a more fit for purpose solution. Similarly, a development resource with in-depth technical knowledge, while introduced in support, can give a new dimension in resolution of complex production issues. The infusion of the key personnel doesn’t necessarily have to be full time, could be part time, but must happen frequently and periodically during application lifecycle. ",
            "ratings": []
        }
    ]
  }
]
