import { Injectable } from '@angular/core';
import {
  HttpClient, HttpEvent, HttpEventType, HttpProgressEvent,
  HttpRequest, HttpResponse, HttpErrorResponse
} from '@angular/common/http';

import { environment } from 'src/environments/environment';
import { AuthenticationService } from '../service';
import { Observable } from 'rxjs';



@Injectable()
export class UploaderService {
  currentUser:any
  id: string;
  constructor(
    private http: HttpClient,
    private authService:AuthenticationService) {
      this.authService.currentUser.subscribe(user=> this.currentUser = user)
    }

  // If uploading multiple files, change to:
  // upload(files: FileList) {
  //   const formData = new FormData();
  //   files.forEach(f => formData.append(f.name, f));
  //   new HttpRequest('POST', '/upload/file', formData, {reportProgress: true});
  //   ...
  // }

  upload(file: File,qid:number) {
    console.log("current user isss " , this.currentUser)
    let uploadURL = `${environment.apiUrl}devops/user/${this.currentUser.userId}/question/${qid}/uploadFile`;
    if (!file) { return; }
    const req = new HttpRequest('POST', uploadURL, file, {
      reportProgress: true
    });
    const formData= new FormData(); 
    formData.append('file',file);
    // The `HttpClient.request` API produces a raw event stream
    // which includes start (sent), progress, and response events.
    return this.http.post(uploadURL,formData).subscribe(res=> {
      console.log(res);
      return res;
    })
  }

getFilesByUserId():Observable<any>{
  let getFilesURL = `${environment.apiUrl}devops/user/${this.currentUser.userId}/files`;

    return this.http.get<any>(getFilesURL);
}
  Delete(file: File,qid:number){
    let deleteURL = `${environment.apiUrl}devops/file/${this.currentUser.userId}/question/${qid}/uploadFile`;

    return this.http.delete(deleteURL).subscribe(res=>{
      console.log(res);
    })
  }

  /** Return distinct message for sent, upload progress, & response events */
  
}