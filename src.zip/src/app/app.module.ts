import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AccountInfoComponent } from './account-info/account-info.component'
import { InputTextModule } from 'primeng/inputtext';
import { PanelModule } from 'primeng/panel';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MeasureComponent } from './measure/measure.component';
import { TabMenuModule } from 'primeng/tabmenu';
import { AutomateComponent } from './measure/automate/automate.component';
import { CardModule } from 'primeng/card';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { FileUploadModule } from 'primeng/fileupload';
import { DropdownModule } from 'primeng/dropdown';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { AccordionModule } from 'primeng/accordion';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { LoginComponent } from './login/login.component';


/**********prime ng ***************/
import {MenubarModule} from 'primeng/menubar';
import {ButtonModule} from 'primeng/button';
import { HomeComponent } from './home/home.component';
import { ApproachComponent } from './approach/approach.component';
import {TabViewModule} from 'primeng/tabview';
import { UsageTipsComponent } from './usage-tips/usage-tips.component';
import {MessagesModule} from 'primeng/messages';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {DialogModule} from 'primeng/dialog';
import {ConfirmationService} from 'primeng/api';
import { Authentication } from './services/Authentication';
import { AlertService, AuthenticationService, UserService, MessageService } from './services';
import { JwtInterceptor, ErrorInterceptor, fakeBackendProvider } from './helpers';
import {TieredMenuModule} from 'primeng/tieredmenu';
import { ConfigService } from './config/config.service';
import {MessageModule} from 'primeng/message';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import { LoaderComponent } from './loader/loader.component';
import { LoaderService } from './loader/loader.service';
import { LoaderInterceptor } from './helpers/loader.interceptor';
import { AlertComponent } from './alert/alert.component';
import { ReportComponent } from './report/report.component';
import { HttpErrorHandler } from './services/http-error-handler.service';
import { AccountInformationService } from './account-info/account-info.services';
import { UploaderService } from './measure/upload.service';

@NgModule({
  declarations: [
    AppComponent,
    AccountInfoComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    ApproachComponent,
    MeasureComponent,
    AutomateComponent,
    UsageTipsComponent,
    LoginComponent,
    LoaderComponent,
    AlertComponent,
    ReportComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    InputTextModule,
    PanelModule,
    ButtonModule,
    MenubarModule,
    TabMenuModule,
    CardModule,
    InputTextareaModule,
    FileUploadModule,
    DropdownModule,
    OverlayPanelModule,
    AccordionModule,
    TabViewModule,
    HttpClientModule,
    ConfirmDialogModule,
    DialogModule,
    TieredMenuModule,
    MessageModule,
    MessagesModule,
    ProgressSpinnerModule,
  ],
  providers: [
    ConfirmationService,
    Authentication,
    AlertService,
    AuthenticationService,
    MessageService,
    ConfigService,
    UserService,
    HttpErrorHandler,
    AccountInformationService,
    LoaderService,
    UploaderService,
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true }

    // provider used to create fake backend
   // fakeBackendProvider
],
  bootstrap: [AppComponent]
})
export class AppModule {

 }
