
import { Component } from '@angular/core'
//import { environment }  from '../../environments/environment'

interface options {
    label: string,
    code: string
}

@Component({
    selector: 'account-info',
    templateUrl: './account-info.component.html',
    styleUrls: ['./account-info.component.css']

})
export class AccountInfoComponent {
    accountInfoTitle = "Account Information*"
    accountScopeTitle = "Account Scope*";
   // environmentValue = environment;

    options1: options[]
    options2: options[]
    options3: options[]
    options4: options[]

    constructor() {
        this.options1 = [
            {label: 'Yes', code: 'Y'},
            {label: 'No', code: 'N'},
        ]
        this.options2 = [
            {label: 'Ops changes only', code: '1'},
            {label: 'Project changes as well', code: '2'},
        ]
        this.options3 = [
            {label: 'E2E', code: '1'},
            {label: 'Partially', code: '2'},
        ]
        this.options4 = [
            {label: 'Internal', code: '1'},
            {label: 'Customer', code: '2'},
            {label: 'Both', code: '3'}
        ]
    }
}