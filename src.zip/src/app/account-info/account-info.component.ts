
import { Component, OnInit } from '@angular/core'
import { environment }  from '../../environments/environment'
import { FormGroup } from '@angular/forms';

import { AccountInformationService } from './account-info.services';
import { AccountInformation } from './account-info';
import { Observable } from 'rxjs';


interface options {
    label: string,
    code: string
}

@Component({
    selector: 'account-info',
    templateUrl: './account-info.component.html',
    styleUrls: ['./account-info.component.css']

})
export class AccountInfoComponent implements OnInit { 
    userForm: FormGroup;
    Data:any;
    accountInfoTitle = "Account Information*"
    accountScopeTitle = "Account Scope*";
    environmentValue = environment;
    model: AccountInformation = new AccountInformation();
    accountInformation: AccountInformation[]=[];
    editAccountInfo: AccountInformation;
    options2: string[];
    options3: string[];
    options1 = ['Yes', 'No'];
    private accountId: string;
    // options1: options[]
   
    //options3: ['E2E', 'Partially'];
    options4: string[];
  
   
    
    constructor( private accountService: AccountInformationService) {

        this.options2 = ['Ops changes only','Project changes as well'];
        this.options3 = ['E2E', 'Partially'];
        this.options4 = ['Internal','Customer','Both'];
    }
    value: any;

    // change(){
     
    //       this.model.forEach(function(data)
    //     {
    //       console.log("value of the data iss  " + data.id);
    //     })
    // }
  url(url: any) {
    throw new Error("Method not implemented.");
  }
    ngOnInit() {
    //  this.options2 = ['Ops changes only','Project changes as well'];
     console.log("into the ngonit method");
     this.getAccount();
      
    }
    getAccount():void{
      console.log("************ into the get account ***********");
      this.accountService.getAccountInformation()
      .subscribe(data=>{
        console.log(data);
        if(!!data){
          this.accountId = data.id;
        this.model=data
        }else{
           this.model = new AccountInformation();
        }
        });
      console.log("************ END the get account ***********");
    }

   
    submit(form) {
      
    let accountData: AccountInformation;
    accountData=form;
     if(!!this.accountId){
      accountData.id = this.accountId;
       this.updateAccount(accountData);
     }else{
       this.createAccount(accountData);
     }
    } 
    createAccount(accountData: AccountInformation){
      console.log("into the post editAccountInfo " , accountData);
      return this.accountService.addAccountInformation(accountData).subscribe(data =>{ 
        this.fetchAccount();
      });
    }
      // const newData:AccountInformation={form} as AccountInformation;
      // return this.http.post(this.heroesUrl,this.value).subscribe(data => {console.log("POST Request is successful ", data);},
      // error =>{
      //   console.log("Error",error);
      // }
      
      // );
       
    
 
  updateAccount(accountData: AccountInformation) {
      console.log("into the update method");
        this.accountService.updateHero(accountData)
          .subscribe(data => {
            this.fetchAccount()
          });
      }
    private fetchAccount(){
      this.accountService.getAccountInformation()
      .subscribe(data=>{
        console.log(data);
        if(!!data){
          this.accountId = data.id;
        this.model=data
        }else{
           this.model = new AccountInformation();
        }
        });
    }
    

}