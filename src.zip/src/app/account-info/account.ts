export class AccountInformation{
    id:string;
    name: string;
    teamsize: number;
    customerlocation: string;
    contracttype: string;
    deliverymanager: string;
    technology: string;
    deliverylocation: string;
    startDate: string;
    l1L2ServiceSupport: string;
    devL3ServiceSupport: string;
    sepDevOPTeams: string;
    smallFrequentorProjectChanges: string;
    complianceregulatoryRestrictions: string;
    e2eSDLCProjectEnhancements: string;
    internalCustomerBoth: string;
}