import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpErrorHandler, HandleError } from '../services/http-error-handler.service';

import { environment } from 'src/environments/environment';
import { AccountInformation } from './account-info';
import { AuthenticationService } from '../services';


// var currentUser = JSON.parse(localStorage.getItem('currentUser')); 

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Access-Control-Allow-Origin': '*'
  })
};

@Injectable()
export class AccountInformationService {
  // currentUser = JSON.parse(localStorage.getItem('currentUser')); 
  currentUser:any
  userId:number =5000
  // heroesUrl = 'api/heroes';  // URL to web api
  private handleError: HandleError;
  

//   private handleError: HandleError;
  constructor(
    private http: HttpClient,
    private authService: AuthenticationService,
    httpErrorHandler: HttpErrorHandler) {
    this.handleError = httpErrorHandler.createHandleError('AccountInformationService');
     this.authService.currentUser.subscribe(user=> this.currentUser = user)
  }

    
  
    addAccountInformation (accInfo: AccountInformation): Observable<AccountInformation> {
        return this.http.post<AccountInformation>(`${environment.apiUrl}devops/user/${this.currentUser.userId}/account`, accInfo, httpOptions)
          .pipe(
            catchError(this.handleError('addAccInfo', accInfo))
          );
      }

    getAccountInformation():Observable<AccountInformation>{
      
      return this.http.get<AccountInformation>(`${environment.apiUrl}devops/user/${this.currentUser.userId}/account`);

    }
    updateHero (accInfo: AccountInformation): Observable<AccountInformation> {
      httpOptions.headers =
        httpOptions.headers.set('Authorization', 'my-new-auth-token');
  
      return this.http.put<AccountInformation>(`${environment.apiUrl}devops/account`, accInfo, httpOptions)
        .pipe(
          catchError(this.handleError('updateHero', accInfo))
        );
    }
}
