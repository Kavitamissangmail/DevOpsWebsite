import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { AlertService } from '../services/alert.service';
import { AuthenticationService } from '../services/authentication.service';
import { User } from '../models';
import { throwError } from 'rxjs';


@Component({templateUrl: 'login.component.html'})
export class LoginComponent implements OnInit {
    loginForm: FormGroup;
    loading = false;
    submitted = false;
    returnUrl: string;
   // user: User= new User(1, "admin", "admin")

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService,
        private alertService: AlertService
    ) {
        // redirect to home if already logged in
        console.log(this.authenticationService.currentUserValue)
        if (this.authenticationService.currentUserValue) { 
            this.router.navigate(['home']);
        }
       // const mapped = [{"firstName":"Admin","lastName":"User","username":"admin","password":"admin","id":1}]
       // localStorage.setItem('users', JSON.stringify(mapped));
    }

    ngOnInit(): void {
        this.loginForm = this.formBuilder.group({
            username: ['', Validators.required],
            password: ['', Validators.required]
        });
        // localStorage.removeItem('currentUser');
        // // get return url from route parameters or default to '/'
        // this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';

        // reset login status
       // this.authenticationService.logout();

        // get return url from route parameters or default to '/'
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || 'home';



    }

    // convenience getter for easy access to form fields
    get f() { return this.loginForm.controls; }

    onSubmit() {
        this.submitted = true;

        // stop here if form is invalid
        if (this.loginForm.invalid) {
            return;
        }

        this.loading = true;
        this.authenticationService.login(this.f.username.value, this.f.password.value)
            .pipe(first())
            .subscribe(
                data => {
                    //console.log('data', data)
                    this.router.navigate([this.returnUrl]);
                },
                error => {
                    console.log('error', error)
                   // alert('alert')
                    // this.alertService.error(error);
                    // this.loading = false;
                     // else return 400 bad request
                    
                });
    }
}
