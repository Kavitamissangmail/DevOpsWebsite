import { Component, OnInit } from '@angular/core';
import { User } from '../models';
import {MenuItem} from 'primeng/api';
import { UserService, AuthenticationService } from '../services';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  currentUser: User;
  items: MenuItem[];  
  navbarOpen = false;

  toggleNavbar() {
    this.navbarOpen = !this.navbarOpen;
  }
  
  constructor(private authService: AuthenticationService) {
    // this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
    // console.log(this.currentUser)
   }

  ngOnInit() {
    this.authService.currentUser.subscribe((user)=>{
      console.log('listen', user)
      this.currentUser = user
    }
    )
  }

  logout() {
    this.authService.logout()
  }

}
